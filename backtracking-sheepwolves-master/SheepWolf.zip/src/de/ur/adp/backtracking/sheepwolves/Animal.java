package de.ur.adp.backtracking.sheepwolves;

public interface Animal {

    // Nothing to do here
}
